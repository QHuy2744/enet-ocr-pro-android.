# eNet OCR Pro – Screen AI (bản thử nghiệm)

## Chức năng mới
- Có nút cấp quyền đọc màn hình bằng Android MediaProjection.
- Nút nổi đổi thành **AI**. Khi dịch vụ đọc màn hình đã được bật, chạm nút AI để chụp màn hình hiện tại.
- ML Kit nhận diện chữ trên ảnh màn hình; Gemini 3.8 Flash phân tích nội dung, đưa ra lựa chọn trắc nghiệm hoặc lời giải tự luận.
- Kết quả hiển thị trong thông báo; chạm thông báo để mở lại app và xem OCR/lời giải.
- Không tự bấm Nộp bài hoặc tự thay đổi câu trả lời trong app/web khác.

## Cài đặt và sử dụng
1. Build và cài APK.
2. Mở eNet OCR Pro, vào **Cài API key** và lưu Gemini API key trên điện thoại.
3. Bấm **Nút nổi**, cấp quyền Hiển thị trên ứng dụng khác nếu Android hỏi.
4. Bấm **CẤP QUYỀN ĐỌC MÀN HÌNH**, cho phép thông báo và xác nhận hộp thoại chia sẻ/chụp màn hình của Android.
5. Chuyển sang trang có bài tập, chạm nút nổi **AI**. Đợi thông báo lời giải.

## Giới hạn cần biết
- Android bắt buộc người dùng xác nhận quyền chụp màn hình. Ứng dụng không được âm thầm chụp màn hình.
- Đây là bản thử nghiệm: chỉ phân tích khi người dùng chạm nút AI, không chạy quét liên tục.
- Chất lượng OCR tùy độ rõ của màn hình; Gemini có thể sai hoặc API có thể hết hạn mức/mất mạng.
- Không tự chọn đáp án, không tự mở bàn phím/điền nội dung và không tự nộp bài. Hãy kiểm tra lời giải trước khi sử dụng.
- Sau khi Android thu hồi quyền chia sẻ màn hình hoặc dịch vụ bị dừng, cần cấp quyền lại.
