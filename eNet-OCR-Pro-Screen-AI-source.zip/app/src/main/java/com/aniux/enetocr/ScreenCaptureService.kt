package com.aniux.enetocr

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private var busy = false
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val executor = Executors.newSingleThreadExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startProjection(intent)
            ACTION_CAPTURE -> captureScreen()
        }
        return START_STICKY
    }

    private fun startProjection(intent: Intent) {
        if (projection != null) return
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
                            else intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return }
        val channel = "enet_screen_reader"
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(channel, "eNet AI đọc màn hình", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setContentTitle("eNet AI đang sẵn sàng")
            .setContentText("Mở bài tập và chạm nút nổi AI để đọc màn hình.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)

        try {
            val managerProjection = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = managerProjection.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            worker = HandlerThread("enet-screen-capture").also { it.start() }
            handler = Handler(worker!!.looper)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
            virtualDisplay = projection?.createVirtualDisplay(
                "eNet-AI-Screen", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler
            )
            active = true
            updateStatus("Đã bật đọc màn hình. Chạm nút nổi AI để phân tích trang đang mở.")
        } catch (e: Exception) {
            active = false
            notifyResult("Không bật được đọc màn hình", e.localizedMessage ?: "Android từ chối quyền chụp màn hình.", "")
            stopSelf()
        }
    }

    private fun captureScreen() {
        if (projection == null || reader == null) {
            notifyResult("Chưa bật đọc màn hình", "Mở eNet OCR Pro và cấp quyền đọc màn hình trước.", "")
            return
        }
        if (busy) { updateStatus("AI đang xử lý ảnh trước đó. Vui lòng đợi kết quả."); return }
        busy = true
        updateStatus("Đang chụp màn hình và nhận diện chữ…")
        handler?.postDelayed({
            var image: Image? = null
            try {
                image = reader?.acquireLatestImage()
                if (image == null) {
                    busy = false
                    updateStatus("Chưa lấy được ảnh màn hình. Chạm nút nổi thử lại.")
                    return@postDelayed
                }
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(plane.buffer)
                val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
                padded.recycle()
                image.close(); image = null
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        bitmap.recycle()
                        val text = result.text.trim()
                        if (text.isBlank()) {
                            busy = false
                            notifyResult("Không nhận diện được chữ", "Hãy mở rõ phần bài tập rồi chạm nút AI lần nữa.", "")
                        } else solveWithGemini(text)
                    }
                    .addOnFailureListener { error ->
                        bitmap.recycle(); busy = false
                        notifyResult("Lỗi OCR", error.localizedMessage ?: "Không nhận diện được chữ trên màn hình.", "")
                    }
            } catch (e: Exception) {
                image?.close(); busy = false
                notifyResult("Lỗi chụp màn hình", e.localizedMessage ?: "Không đọc được khung hình.", "")
            }
        }, 500)
    }

    private fun solveWithGemini(exercise: String) {
        val key = getSharedPreferences("ocr", MODE_PRIVATE).getString("gemini_api_key", "").orEmpty().trim()
        if (key.isBlank()) {
            busy = false
            notifyResult("Chưa cài Gemini API key", "Mở eNet OCR Pro → Cài API key, sau đó thử lại.", exercise)
            return
        }
        updateStatus("Đã đọc đề. Gemini đang phân tích và tạo lời giải…")
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val model = "gemini-3.8-flash"
                connection = (URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000; doOutput = true
                    setRequestProperty("x-goog-api-key", key)
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val prompt = "Bạn là trợ lý học tập tiếng Việt cho học sinh THCS. Hãy đọc nội dung OCR (có thể sai), xác định từng câu hỏi; với trắc nghiệm hãy nêu lựa chọn phù hợp và lý do; với tự luận hãy giải thích từng bước và ghi câu trả lời mẫu. Nếu không đọc chắc hoặc thiếu dữ kiện, ghi rõ phần chưa chắc, không tự đoán. Không thực hiện thao tác nộp bài.\n\nNỘI DUNG MÀN HÌNH:\n$exercise"
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 3500))
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = JSONObject(raw)
                if (code !in 200..299) throw IllegalStateException("Gemini HTTP $code: ${json.optJSONObject("error")?.optString("message") ?: raw.take(300)}")
                val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val answer = if (parts == null) "" else (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text")?.takeIf(String::isNotBlank) }.joinToString("\n")
                if (answer.isBlank()) throw IllegalStateException("Gemini trả về nội dung rỗng.")
                busy = false
                notifyResult("eNet AI đã phân tích bài tập", answer, exercise)
            } catch (e: Exception) {
                busy = false
                notifyResult("Không tạo được lời giải", e.localizedMessage ?: "Lỗi kết nối Gemini.", exercise)
            } finally { connection?.disconnect() }
        }
    }

    private fun updateStatus(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, Notification.Builder(this, "enet_screen_reader")
            .setContentTitle("eNet AI đang sẵn sàng").setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build())
    }

    private fun notifyResult(title: String, message: String, exercise: String) {
        val open = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_OCR_TEXT, exercise)
            putExtra(EXTRA_ANSWER, message)
        }
        val pending = PendingIntent.getActivity(this, 81, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, "enet_screen_reader")
            .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle(title)
            .setContentText(message.take(180)).setStyle(NotificationCompat.BigTextStyle().bigText(message.take(3500)))
            .setContentIntent(pending).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        getSystemService(NotificationManager::class.java).notify(RESULT_NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        active = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        worker?.quitSafely()
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.aniux.enetocr.START_SCREEN_READER"
        const val ACTION_CAPTURE = "com.aniux.enetocr.CAPTURE_SCREEN_NOW"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_PROJECTION_DATA = "projection_data"
        const val EXTRA_OCR_TEXT = "screen_ocr_text"
        const val EXTRA_ANSWER = "screen_ai_answer"
        private const val NOTIFICATION_ID = 280
        private const val RESULT_NOTIFICATION_ID = 281
        @Volatile var active: Boolean = false
    }
}
