package com.aniux.enetocr

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView

class FloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: View? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        running = true
        val channel = "enet_ocr_floating"
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channel, "eNet OCR Pro", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
        startForeground(27, notification.setContentTitle("eNet OCR Pro").setContentText("Nút nổi đang hoạt động").setSmallIcon(android.R.drawable.ic_menu_search).build())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = TextView(this).apply { text = "OCR"; textSize = 14f; setTextColor(0xff081018.toInt()); setBackgroundColor(0xff22d3ee.toInt()); gravity = Gravity.CENTER; elevation = 12f; setPadding(22, 14, 22, 14) }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 240 }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        v.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); windowManager?.updateViewLayout(v, params); true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawX - downX) < 8 && kotlin.math.abs(event.rawY - downY) < 8) { val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP); startActivity(i) }; true }
                else -> false
            }
        }
        bubble = v
        windowManager?.addView(v, params)
        return START_STICKY
    }

    override fun onDestroy() { bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }; bubble = null; running = false; super.onDestroy() }
    companion object { @Volatile var running = false }
}
