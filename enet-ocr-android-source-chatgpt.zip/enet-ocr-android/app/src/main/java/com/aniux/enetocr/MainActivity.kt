package com.aniux.enetocr

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val cyan = Color.rgb(34, 211, 238)
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(22, 35, 56)
    private lateinit var result: EditText
    private lateinit var status: TextView
    private val selected = mutableListOf<Uri>()
    private var currentName = "ocr"
    private val prefs by lazy { getSharedPreferences("ocr", MODE_PRIVATE) }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 18); setBackgroundColor(bg) }
        fun text(s: String, size: Float = 14f): TextView = TextView(this).apply { text = s; textSize = size; setTextColor(cyan); setPadding(4, 8, 4, 8) }
        fun button(s: String, action: () -> Unit): Button = Button(this).apply { text = s; setTextColor(Color.WHITE); setBackgroundColor(panel); setOnClickListener { action() } }
        root.addView(text("◈ eNet OCR PRO", 24f))
        root.addView(text("OCR đa ảnh • Lịch sử • Xuất và chia sẻ", 12f))
        status = text("Sẵn sàng.")
        root.addView(status)
        val row1 = LinearLayout(this)
        row1.addView(button("CHỌN ẢNH") { pickImages() }, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(button("QUÉT ẢNH") { scanNext(0, StringBuilder()) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row1)
        result = EditText(this).apply {
            hint = "Văn bản nhận diện sẽ xuất hiện ở đây. Có thể chỉnh sửa trước khi lưu."
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setBackgroundColor(panel)
            gravity = Gravity.TOP; minLines = 8; setPadding(12, 12, 12, 12)
        }
        root.addView(result, LinearLayout.LayoutParams(-1, 0, 1f))
        val row2 = LinearLayout(this)
        row2.addView(button("LỊCH SỬ / TÌM") { showHistory() }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(button("LƯU TXT") { saveTxt() }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(button("CHIA SẺ") { shareText() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row2)
        root.addView(button("GIẢI BÀI BẰNG CHATGPT") { sendToChatGPT() })
        root.addView(button("BẬT / TẮT NÚT NỔI") { toggleFloating() })
        setContentView(root)
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true) }
        @Suppress("DEPRECATION") startActivityForResult(Intent.createChooser(i, "Chọn ảnh để OCR"), 101)
    }

    @Deprecated("Legacy result API used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        if (requestCode == 102) {
            val uri = data.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingSave) }
                status.text = "Đã lưu tệp TXT."
            } catch (e: Exception) {
                status.text = "Lỗi lưu TXT: ${e.localizedMessage}"
            }
            return
        }
        if (requestCode != 101) return
        selected.clear()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri) }
        if (selected.isEmpty()) data.data?.let { selected.add(it) }
        status.text = "Đã chọn ${selected.size} ảnh."
        selected.firstOrNull()?.let { currentName = displayName(it).substringBeforeLast('.', "ocr") }
    }

    private fun scanNext(index: Int, all: StringBuilder) {
        if (selected.isEmpty()) { status.text = "Hãy chọn ít nhất một ảnh trước."; return }
        if (index >= selected.size) {
            result.setText(all.toString().trim())
            status.text = "Đã quét ${selected.size} ảnh. Có thể chỉnh sửa kết quả."
            addHistory(currentName, all.toString())
            return
        }
        status.text = "Đang quét ảnh ${index + 1}/${selected.size}…"
        try {
            val image = InputImage.fromFilePath(this, selected[index])
            recognizer.process(image)
                .addOnSuccessListener { vision ->
                    if (all.isNotEmpty()) all.append("\n\n──────── ẢNH ${index + 1} ────────\n")
                    all.append(vision.text)
                    scanNext(index + 1, all)
                }
                .addOnFailureListener { e -> status.text = "Lỗi OCR: ${e.localizedMessage}" }
        } catch (e: Exception) { status.text = "Không mở được ảnh: ${e.localizedMessage}" }
    }

    private fun addHistory(name: String, text: String) {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val obj = JSONObject().put("time", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())).put("name", name).put("text", text)
        arr.put(obj)
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 100) until arr.length()) trimmed.put(arr.getJSONObject(i))
        prefs.edit().putString("history", trimmed.toString()).apply()
    }

    private fun showHistory() {
        val query = EditText(this).apply { hint = "Tìm theo tên ảnh hoặc nội dung"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 10, 16, 10); setBackgroundColor(bg) }
        val list = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }
        fun refresh(q: String) {
            val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
            val lines = mutableListOf<String>()
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i); val name = o.optString("name"); val txt = o.optString("text")
                if (q.isBlank() || name.contains(q, true) || txt.contains(q, true)) lines.add("${o.optString("time")} • $name\n${txt.take(180)}\n")
            }
            list.text = lines.joinToString("\n").ifBlank { "Không có kết quả phù hợp." }
        }
        query.addTextChangedListener(SimpleWatcher { refresh(it) }); box.addView(query); box.addView(list)
        refresh("")
        val scroll = ScrollView(this); scroll.addView(box)
        android.app.AlertDialog.Builder(this).setTitle("Lịch sử OCR").setView(scroll).setPositiveButton("Đóng", null).show()
    }

    private fun saveTxt() {
        val content = result.text.toString()
        if (content.isBlank()) { status.text = "Chưa có văn bản để lưu."; return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "${currentName}_${System.currentTimeMillis()}.txt") }
        pendingSave = content
        startActivityForResult(intent, 102)
    }

    private var pendingSave = ""
    private fun shareText() {
        val content = result.text.toString()
        if (content.isBlank()) { status.text = "Chưa có văn bản để chia sẻ."; return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, content) }, "Chia sẻ văn bản OCR"))
    }

    private fun sendToChatGPT() {
        val ocrText = result.text.toString().trim()
        if (ocrText.isBlank()) {
            status.text = "Chưa có nội dung. Hãy chọn ảnh và quét ảnh trước."
            return
        }
        val prompt = "Hãy giải bài tập trong nội dung bên dưới. Trình bày rõ ràng theo từng câu, dùng cách giải phù hợp học sinh THCS và ghi đáp án cuối mỗi câu. Nội dung có thể bị OCR nhận diện sai; hãy dựa vào ngữ cảnh và nói rõ nếu chỗ nào không đọc chắc chắn.\n\nBÀI TẬP:\n$ocrText"
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, prompt)
        }
        try {
            startActivity(Intent.createChooser(shareIntent, "Gửi bài tập sang ChatGPT"))
            status.text = "Đã chuẩn bị nội dung. Chọn ChatGPT trong bảng chia sẻ rồi bấm gửi."
        } catch (e: Exception) {
            status.text = "Không mở được bảng chia sẻ: ${e.localizedMessage}"
        }
    }

    private fun toggleFloating() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text = "Hãy bật quyền Hiển thị trên ứng dụng khác, rồi quay lại bấm nút này."
            return
        }
        if (FloatingService.running) stopService(Intent(this, FloatingService::class.java))
        else startForegroundService(Intent(this, FloatingService::class.java))
        status.text = if (FloatingService.running) "Đã bật nút nổi." else "Đã tắt nút nổi."
    }

    private fun displayName(uri: Uri): String {
        var name = "ocr-image"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) }
        return name
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent) }
}

private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
