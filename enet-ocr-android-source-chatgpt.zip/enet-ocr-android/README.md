# eNet OCR Pro Android (source scaffold)

This is a native Android Studio source project created from the feature goals in the supplied Termux Python scripts. It does not overwrite or replace `popup-ocr-pro.py` or `popup-ocr-future.py`.

Features implemented in this source scaffold:
- Dark navy / cyan UI
- Android photo picker with multi-image selection
- On-device ML Kit Latin text recognition (Vietnamese/English use Latin script)
- Editable OCR result
- Local history with text search
- Save as TXT using Android document picker
- Share recognized text
- Send the recognized exercise text to ChatGPT through Android share sheet (the user chooses ChatGPT and taps Send; answers are not generated inside the app itself)
- Draggable floating OCR launcher using Android overlay permission

Important status:
- This is source code, not a compiled APK. It needs Android Studio/Android SDK and Gradle to build and test.
- The floating bubble opens the app main screen; it is a launcher, not a full OCR mini-window.
- Floating service behavior and Android 14/15 foreground-service restrictions must be tested on the target phone.
- Save TXT writes the edited result through Android’s document picker. Treat this as a development scaffold, not a finished production release.
- ML Kit Latin recognizer handles Vietnamese/English Latin text, but may need language-specific tuning for difficult layouts.

Build with Android Studio: open this folder as a project, allow Gradle sync, then Build > Build APK(s). Do not replace the original Termux scripts until the APK has been tested.
