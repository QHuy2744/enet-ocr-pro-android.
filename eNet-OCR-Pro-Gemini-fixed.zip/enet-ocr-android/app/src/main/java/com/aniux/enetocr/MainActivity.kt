package com.aniux.enetocr

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val cyan = Color.rgb(43, 211, 255)
    private val blue = Color.rgb(34, 105, 255)
    private val bg = Color.rgb(5, 10, 24)
    private val panel = Color.rgb(13, 25, 48)
    private val panel2 = Color.rgb(18, 36, 66)
    private val white = Color.rgb(237, 245, 255)
    private val muted = Color.rgb(151, 174, 205)
    private lateinit var ocrResult: EditText
    private lateinit var solutionResult: TextView
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var subjectSpinner: Spinner
    private lateinit var taskSpinner: Spinner
    private lateinit var solveButton: Button
    private val selected = mutableListOf<Uri>()
    private var currentName = "Bai_tap"
    private var pendingSave = ""
    private val prefs by lazy { getSharedPreferences("ocr", MODE_PRIVATE) }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts?.language = Locale("vi", "VN")
        }
        buildUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 18, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun gradient(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(20, 62, 142), Color.rgb(18, 28, 66), Color.rgb(12, 20, 43))
    ).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), Color.rgb(24, 119, 210)) }

    private fun label(value: String, size: Float = 14f, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(4), dp(2), dp(4))
            if (android.os.Build.VERSION.SDK_INT >= 21) letterSpacing = 0.01f
        }

    private fun actionButton(value: String, primary: Boolean = false, action: () -> Unit): Button =
        Button(this).apply {
            text = value
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = if (primary) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(blue, Color.rgb(0, 184, 255))).apply { cornerRadius = dp(15).toFloat() } else rounded(panel2, 15, Color.rgb(43, 80, 130))
            minHeight = dp(48)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            stateListAnimator = null
            setOnClickListener { action() }
        }

    private fun makeCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(13), dp(15), dp(15))
        background = rounded(panel, 20, Color.rgb(28, 57, 96))
        elevation = dp(2).toFloat()
    }

    private fun sectionTitle(title: String, subtitle: String = ""): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 17f, white, true))
        if (subtitle.isNotBlank()) addView(label(subtitle, 12f, muted))
        setPadding(0, dp(3), 0, dp(8))
    }

    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun addGap(parent: LinearLayout, height: Int = 12) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height))) }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false; isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = gradient()
            setPadding(dp(14), dp(15), dp(12), dp(15))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ocr_logo)
            contentDescription = "Biểu tượng eNet OCR Pro"
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(74), dp(74)))
        val headerText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        headerText.addView(label("eNet OCR Pro", 23f, white, true))
        headerText.addView(label("Quét ảnh • Giải bài • Học thông minh", 12f, cyan))
        headerText.addView(label("Bài tập của bn, lời giải ngay trong app", 11f, muted))
        header.addView(headerText, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        addGap(root, 10)

        val featureLine = row().apply {
            addView(featureChip("📷 OCR"), LinearLayout.LayoutParams(0, -2, 1f))
            addView(featureChip("✨ AI giải bài"), LinearLayout.LayoutParams(0, -2, 1f))
            addView(featureChip("🔊 Đọc lời giải"), LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(featureLine)
        addGap(root, 12)

        val scanCard = makeCard()
        scanCard.addView(sectionTitle("01  •  ẢNH BÀI TẬP", "Chọn một hoặc nhiều ảnh từ thư viện, sau đó nhận diện chữ."))
        val scanRow = row()
        scanRow.addView(actionButton("🖼  Chọn ảnh", false) { pickImages() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        scanRow.addView(actionButton("🔎  Nhận diện OCR", true) { scanNext(0, StringBuilder()) }, LinearLayout.LayoutParams(0, -2, 1.25f).apply { marginStart = dp(6) })
        scanCard.addView(scanRow)
        count = label("Chưa chọn ảnh nào.", 12f, muted)
        scanCard.addView(count)
        root.addView(scanCard)
        addGap(root)

        val ocrCard = makeCard()
        ocrCard.addView(sectionTitle("02  •  VĂN BẢN ĐÃ NHẬN DIỆN", "Có thể sửa lại chữ sai trước khi yêu cầu AI giải."))
        ocrResult = EditText(this).apply {
            hint = "Nội dung bài tập sẽ hiển thị tại đây…"
            setHintTextColor(Color.rgb(104, 129, 165))
            setTextColor(white)
            textSize = 15f
            gravity = Gravity.TOP or Gravity.START
            minLines = 5
            maxLines = 12
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(7, 16, 34), 14, Color.rgb(31, 66, 111))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        ocrCard.addView(ocrResult, LinearLayout.LayoutParams(-1, dp(175)))
        addGap(ocrCard, 8)
        val ocrActions = row()
        ocrActions.addView(actionButton("Sao chép", false) { copyText(ocrResult.text.toString(), "Văn bản OCR") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
        ocrActions.addView(actionButton("Lưu TXT", false) { saveTxt(ocrResult.text.toString(), "${currentName}_ocr.txt") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        ocrActions.addView(actionButton("Xóa", false) { ocrResult.setText(""); status.text = "Đã xóa văn bản OCR." }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        ocrCard.addView(ocrActions)
        root.addView(ocrCard)
        addGap(root)

        val aiCard = makeCard().apply { background = rounded(Color.rgb(10, 25, 49), 22, Color.rgb(32, 116, 220)) }
        aiCard.addView(sectionTitle("03  •  GIẢI BÀI NGAY TRONG APK", "AI tạo lời giải và hiển thị ở màn hình này — không cần chuyển sang ứng dụng khác."))
        aiCard.addView(label("MÔN HỌC", 11f, cyan, true))
        subjectSpinner = spinner(listOf("Tự nhận diện môn", "Toán", "Ngữ văn", "Tiếng Anh", "Vật lý", "Hóa học", "Sinh học", "Lịch sử & Địa lý", "Tin học"))
        aiCard.addView(subjectSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        addGap(aiCard, 8)
        aiCard.addView(label("CÁCH AI HỖ TRỢ", 11f, cyan, true))
        taskSpinner = spinner(listOf("Giải chi tiết từng bước", "Giải thích dễ hiểu như THCS", "Chỉ nêu đáp án ngắn gọn", "Tóm tắt nội dung", "Tạo câu hỏi ôn tập"))
        aiCard.addView(taskSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        addGap(aiCard, 10)
        solveButton = actionButton("✨  GIẢI BÀI BẰNG AI", true) { solveInApp() }
        aiCard.addView(solveButton, LinearLayout.LayoutParams(-1, dp(54)))
        aiCard.addView(label("Dùng Gemini API key của riêng bn. Hạn mức Gemini phụ thuộc tài khoản; không dán key vào GitHub.", 11f, muted))
        root.addView(aiCard)
        addGap(root)

        val answerCard = makeCard()
        answerCard.addView(sectionTitle("04  •  LỜI GIẢI", "Kết quả AI sẽ xuất hiện tại đây để bn đọc, sao chép, nghe hoặc lưu."))
        solutionResult = TextView(this).apply {
            text = "Chưa có lời giải. Chọn ảnh → nhận diện OCR → bấm Giải bài bằng AI."
            textSize = 15f
            setTextColor(white)
            setLineSpacing(dp(4).toFloat(), 1.03f)
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(Color.rgb(7, 16, 34), 14, Color.rgb(31, 66, 111))
            setTextIsSelectable(true)
            gravity = Gravity.TOP or Gravity.START
        }
        solutionResult.minHeight = dp(170)
        answerCard.addView(solutionResult, LinearLayout.LayoutParams(-1, -2))
        addGap(answerCard, 8)
        val answerRow1 = row()
        answerRow1.addView(actionButton("📋 Sao chép lời giải", false) { copyText(solutionResult.text.toString(), "Lời giải") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        answerRow1.addView(actionButton("🔊 Đọc thành tiếng", false) { speakSolution() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        answerCard.addView(answerRow1)
        addGap(answerCard, 7)
        val answerRow2 = row()
        answerRow2.addView(actionButton("💾 Lưu lời giải TXT", false) { saveTxt(solutionResult.text.toString(), "${currentName}_loi_giai.txt") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        answerRow2.addView(actionButton("↗ Chia sẻ", false) { shareText(solutionResult.text.toString(), "Chia sẻ lời giải") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        answerCard.addView(answerRow2)
        root.addView(answerCard)
        addGap(root)

        val toolsCard = makeCard()
        toolsCard.addView(sectionTitle("05  •  CÔNG CỤ HỌC TẬP", "Quản lý bài đã quét và tùy chỉnh kết nối AI."))
        val toolsRow = row()
        toolsRow.addView(actionButton("🕘 Lịch sử", false) { showHistory() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        toolsRow.addView(actionButton("🔑 Cài API key", false) { showApiKeyDialog() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        toolsRow.addView(actionButton("◉ Nút nổi", false) { toggleFloating() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        toolsCard.addView(toolsRow)
        root.addView(toolsCard)
        addGap(root, 10)

        status = label("● Sẵn sàng. Chưa có dữ liệu gửi đi.", 12f, cyan)
        status.setPadding(dp(5), dp(5), dp(5), dp(5))
        root.addView(status)
        root.addView(label("Học tập có trách nhiệm • Hãy kiểm tra lại các bước và đáp án trước khi nộp bài.", 11f, muted))
        setContentView(scroll)
    }

    private fun featureChip(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 11f
        gravity = Gravity.CENTER
        setTextColor(cyan)
        setPadding(dp(3), dp(8), dp(3), dp(8))
        background = rounded(Color.rgb(10, 27, 54), 13, Color.rgb(26, 66, 115))
    }

    private fun spinner(values: List<String>): Spinner = Spinner(this).apply {
        val choiceAdapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, values) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return (super.getView(position, convertView, parent) as TextView).apply {
                    setTextColor(white)
                    textSize = 14f
                    setPadding(dp(12), dp(5), dp(12), dp(5))
                }
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    setTextColor(white)
                    setBackgroundColor(panel2)
                    textSize = 14f
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                }
            }
        }
        choiceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        adapter = choiceAdapter
        background = rounded(Color.rgb(7, 16, 34), 13, Color.rgb(31, 66, 111))
    }

    private fun pickImages() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION") startActivityForResult(Intent.createChooser(intent, "Chọn ảnh bài tập"), 101)
    }

    @Deprecated("Legacy result API supports older Android versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        if (requestCode == 102) {
            val uri = data.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingSave) }
                status.text = "● Đã lưu tệp TXT thành công."
            } catch (e: Exception) { status.text = "● Lỗi lưu TXT: ${e.localizedMessage ?: "không rõ nguyên nhân"}" }
            return
        }
        if (requestCode != 101) return
        selected.clear()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri) }
        if (selected.isEmpty()) data.data?.let { selected.add(it) }
        count.text = "Đã chọn ${selected.size} ảnh. Nhấn Nhận diện OCR để đọc chữ."
        status.text = "● Đã chọn ${selected.size} ảnh."
        selected.firstOrNull()?.let { currentName = displayName(it).substringBeforeLast('.', "Bai_tap").replace(Regex("[^\\p{L}\\p{N}_-]"), "_") }
    }

    private fun scanNext(index: Int, all: StringBuilder) {
        if (selected.isEmpty()) { status.text = "● Hãy chọn ít nhất một ảnh trước."; return }
        if (index >= selected.size) {
            val text = all.toString().trim()
            ocrResult.setText(text)
            count.text = "Đã nhận diện ${selected.size} ảnh. Có thể sửa chữ sai bên trên."
            status.text = "● OCR hoàn tất. Kiểm tra chữ rồi bấm Giải bài bằng AI."
            addHistory(currentName, text)
            return
        }
        status.text = "● Đang nhận diện ảnh ${index + 1}/${selected.size}…"
        try {
            val image = InputImage.fromFilePath(this, selected[index])
            recognizer.process(image)
                .addOnSuccessListener { vision ->
                    if (all.isNotEmpty()) all.append("\n\n──────── ẢNH ${index + 1} ────────\n")
                    all.append(vision.text)
                    scanNext(index + 1, all)
                }
                .addOnFailureListener { e -> status.text = "● Lỗi OCR: ${e.localizedMessage ?: "không thể đọc ảnh"}" }
        } catch (e: Exception) { status.text = "● Không mở được ảnh: ${e.localizedMessage ?: "lỗi tệp"}" }
    }

    private fun solveInApp() {
        val exercise = ocrResult.text.toString().trim()
        if (exercise.isBlank()) {
            status.text = "● Chưa có bài tập. Hãy chọn ảnh rồi nhận diện OCR trước."
            return
        }
        val key = prefs.getString("gemini_api_key", "").orEmpty().trim()
        if (key.isBlank()) {
            showApiKeyDialog { solveInApp() }
            return
        }
        solveButton.isEnabled = false
        solveButton.text = "⏳  ĐANG GIẢI BÀI…"
        solutionResult.text = "AI đang đọc đề và soạn lời giải. Vui lòng giữ mạng kết nối…"
        status.text = "● Đang gửi bài tập tới AI."
        val subject = subjectSpinner.selectedItem?.toString() ?: "Tự nhận diện môn"
        val task = taskSpinner.selectedItem?.toString() ?: "Giải chi tiết từng bước"
        val prompt = buildString {
            append("Môn học: ").append(subject).append("\nYêu cầu: ").append(task)
            append("\n\nNội dung nhận diện từ ảnh (có thể sai OCR):\n")
            append(exercise)
            append("\n\nHãy giải bằng tiếng Việt. Tách rõ từng câu; dùng công thức và phép biến đổi phù hợp học sinh THCS khi thích hợp; giải thích từng bước; ghi đáp án cuối mỗi câu. Nếu đề bị OCR sai hoặc thiếu dữ kiện, nêu giả định rõ ràng thay vì bịa dữ kiện. Với Ngữ văn/ngoại ngữ, trả lời đúng dạng bài và nêu lý do ngắn gọn. Không chỉ đưa đáp án trống không.")
        }
        requestGemini(key, prompt) { answer, error ->
            solveButton.isEnabled = true
            solveButton.text = "✨  GIẢI BÀI BẰNG AI"
            if (answer != null) {
                solutionResult.text = answer
                status.text = "● Đã nhận lời giải. Bn hãy kiểm tra lại kết quả và các bước."
                addHistory(currentName, exercise, answer)
            } else {
                solutionResult.text = "Không tạo được lời giải.\n\n${error ?: "Lỗi không xác định."}\n\nKiểm tra kết nối mạng, API key và hạn mức API rồi thử lại."
                status.text = "● Yêu cầu AI thất bại."
            }
        }
    }

    private fun requestGemini(apiKey: String, prompt: String, onDone: (String?, String?) -> Unit) {
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 90000
                    doOutput = true
                    setRequestProperty("x-goog-api-key", apiKey)
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val system = "Bạn là trợ lý học tập bằng tiếng Việt, giải thích cẩn thận và trung thực. Ưu tiên cách trình bày dễ hiểu cho học sinh THCS. Nội dung bạn nhận được là chữ OCR, có thể sai; hãy chỉ rõ chỗ không chắc chắn, không tự bịa dữ kiện."
                val systemInstruction = JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put("text", system))
                )
                val contents = JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                )
                val generationConfig = JSONObject()
                    .put("temperature", 0.2)
                    .put("maxOutputTokens", 3500)
                val body = JSONObject()
                    .put("systemInstruction", systemInstruction)
                    .put("contents", contents)
                    .put("generationConfig", generationConfig)
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
                if (code !in 200..299) {
                    val detail = json.optJSONObject("error")?.optString("message").orEmpty()
                        .ifBlank { "Máy chủ Gemini trả về mã HTTP $code." }
                    mainHandler.post { onDone(null, "Gemini API (HTTP $code): ${detail.take(600)}") }
                } else {
                    val candidates = json.optJSONArray("candidates")
                    val parts = candidates?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                    val answer = if (parts == null) "" else buildString {
                        for (i in 0 until parts.length()) {
                            val part = parts.optJSONObject(i)
                            val text = part?.optString("text").orEmpty()
                            if (text.isNotBlank()) {
                                if (isNotEmpty()) append("\n")
                                append(text)
                            }
                        }
                    }
                    if (answer.isBlank()) {
                        val reason = candidates?.optJSONObject(0)?.optString("finishReason").orEmpty()
                        val detail = if (reason.isNotBlank()) "Gemini không trả lời văn bản (finishReason: $reason)." else "Phản hồi Gemini không có nội dung văn bản."
                        mainHandler.post { onDone(null, detail) }
                    } else mainHandler.post { onDone(answer.trim(), null) }
                }
            } catch (e: Exception) {
                mainHandler.post { onDone(null, "Lỗi kết nối Gemini: ${e.localizedMessage ?: e.javaClass.simpleName}") }
            } finally { connection?.disconnect() }
        }
    }

    private fun showApiKeyDialog(onSaved: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        box.addView(label("Nhập Gemini API key lấy từ Google AI Studio. Key được lưu riêng trên điện thoại này; không chia sẻ hoặc đưa lên GitHub.", 13f, muted))
        box.addView(label("Lưu ý: Gemini API có hạn mức và điều kiện sử dụng tùy tài khoản. Kiểm tra hạn mức trong Google AI Studio trước khi dùng.", 12f, Color.rgb(255, 202, 110)))
        val input = EditText(this).apply {
            hint = "Dán Gemini API key tại đây"
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(7, 16, 34), 12, Color.rgb(31, 66, 111))
            setText(prefs.getString("gemini_api_key", ""))
        }
        box.addView(input, LinearLayout.LayoutParams(-1, dp(52)))
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Cài kết nối AI")
            .setView(box)
            .setNegativeButton("Để sau", null)
            .setNeutralButton("Xóa key", null)
            .setPositiveButton("Lưu & tiếp tục", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val key = input.text.toString().trim()
                if (key.isBlank()) input.error = "Hãy nhập API key hoặc bấm Để sau."
                else {
                    prefs.edit().putString("gemini_api_key", key).apply()
                    dialog.dismiss()
                    Toast.makeText(this, "Đã lưu API key trên thiết bị.", Toast.LENGTH_SHORT).show()
                    onSaved?.invoke()
                }
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                prefs.edit().remove("gemini_api_key").apply()
                input.setText("")
                Toast.makeText(this, "Đã xóa API key đã lưu.", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun addHistory(name: String, text: String, solution: String = "") {
        if (text.isBlank()) return
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val obj = JSONObject()
            .put("time", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
            .put("name", name)
            .put("text", text)
            .put("solution", solution)
        arr.put(obj)
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 100) until arr.length()) trimmed.put(arr.getJSONObject(i))
        prefs.edit().putString("history", trimmed.toString()).apply()
    }

    private fun showHistory() {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val search = EditText(this).apply {
            hint = "Tìm tên ảnh hoặc nội dung…"
            setTextColor(white); setHintTextColor(Color.GRAY)
            background = rounded(Color.rgb(7, 16, 34), 12, Color.rgb(31, 66, 111))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        box.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        val entries = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(entries)
        fun refresh(q: String) {
            entries.removeAllViews()
            var found = 0
            for (i in arr.length() - 1 downTo 0) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name")
                val text = item.optString("text")
                val answer = item.optString("solution")
                if (q.isNotBlank() && !name.contains(q, true) && !text.contains(q, true) && !answer.contains(q, true)) continue
                found++
                val b = actionButton("${item.optString("time")}  •  $name\n${text.take(90).replace('\n', ' ')}", false) {
                    ocrResult.setText(text)
                    solutionResult.text = answer.ifBlank { "Bản ghi này chưa có lời giải AI." }
                    currentName = name
                    status.text = "● Đã mở bài từ lịch sử."
                }
                b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                b.textSize = 12f
                entries.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
                if (found >= 30) break
            }
            if (found == 0) entries.addView(label("Không có bản ghi phù hợp.", 13f, muted))
        }
        search.addTextChangedListener(SimpleWatcher { refresh(it) })
        refresh("")
        val outer = ScrollView(this).apply { addView(box) }
        android.app.AlertDialog.Builder(this).setTitle("Lịch sử bài tập").setView(outer).setPositiveButton("Đóng", null).show()
    }

    private fun saveTxt(content: String, fileName: String) {
        if (content.isBlank() || content.startsWith("Chưa có lời giải")) {
            status.text = "● Chưa có nội dung để lưu."
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, fileName.replace(Regex("[^\\p{L}\\p{N}._-]"), "_"))
        }
        pendingSave = content
        @Suppress("DEPRECATION") startActivityForResult(intent, 102)
    }

    private fun copyText(content: String, description: String) {
        if (content.isBlank()) { status.text = "● Không có nội dung để sao chép."; return }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(description, content))
        Toast.makeText(this, "Đã sao chép $description.", Toast.LENGTH_SHORT).show()
    }

    private fun shareText(content: String, title: String) {
        if (content.isBlank()) { status.text = "● Không có nội dung để chia sẻ."; return }
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, content) }
        startActivity(Intent.createChooser(intent, title))
    }

    private fun speakSolution() {
        val content = solutionResult.text.toString().trim()
        if (content.isBlank() || content.startsWith("Chưa có lời giải")) {
            status.text = "● Chưa có lời giải để đọc."
            return
        }
        val engine = tts
        if (engine == null) status.text = "● Bộ đọc văn bản chưa sẵn sàng."
        else {
            engine.language = Locale("vi", "VN")
            engine.speak(content.take(3500), TextToSpeech.QUEUE_FLUSH, null, "enet_solution")
            status.text = "● Đang đọc lời giải bằng giọng nói."
        }
    }

    private fun toggleFloating() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text = "● Hãy bật quyền Hiển thị trên ứng dụng khác, rồi quay lại."
            return
        }
        val wasRunning = FloatingService.running
        if (wasRunning) stopService(Intent(this, FloatingService::class.java))
        else if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, FloatingService::class.java))
        else startService(Intent(this, FloatingService::class.java))
        status.text = if (wasRunning) "● Đã yêu cầu tắt nút nổi." else "● Đã yêu cầu bật nút nổi."
    }

    private fun displayName(uri: Uri): String {
        var name = "Bai_tap"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}

private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
