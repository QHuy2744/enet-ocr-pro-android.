# eNet OCR Pro — bản nâng cấp AI trong ứng dụng

## Chức năng
- Giao diện tối xanh neon, có logo ứng dụng.
- Chọn nhiều ảnh từ thư viện và nhận diện văn bản ngay trên thiết bị bằng Google ML Kit.
- Chỉnh sửa nội dung OCR trước khi giải.
- Gọi Gemini API và hiển thị lời giải ngay trong app (không chuyển sang ứng dụng ChatGPT).
- Chọn môn học và dạng hỗ trợ: giải chi tiết, giải thích kiểu THCS, đáp án ngắn, tóm tắt, tạo câu hỏi ôn tập.
- Sao chép, chia sẻ, lưu OCR/lời giải thành TXT, đọc lời giải bằng TTS, tìm và mở lịch sử, nút nổi OCR.

## Cần biết trước khi dùng tính năng AI
- Cần Gemini API key lấy từ Google AI Studio và kết nối internet. Hạn mức miễn phí/chi phí phụ thuộc chính sách và tài khoản Gemini API hiện tại.
- Nhập key bên trong app tại **Cài API key**. Key được lưu trong SharedPreferences riêng của app trên thiết bị; không đưa key vào GitHub hay chia sẻ APK có kèm key. Đây là bản thử nghiệm cá nhân, chưa phải kho lưu trữ key được mã hóa cấp production.
- Mô hình đang đặt là `gemini-3.8-flash` qua REST `generateContent`; nếu Google đổi model/hạn mức, kiểm tra tài liệu Gemini API mới nhất.
- OCR và TTS chạy cục bộ; riêng lời giải AI được gửi tới dịch vụ Gemini để xử lý. Không nhập dữ liệu nhạy cảm.

## Build từ GitHub Actions
File ZIP chứa thư mục `enet-ocr-android/` và không có Gradle Wrapper. Hãy dùng workflow cài Gradle trực tiếp, đặt `working-directory: enet-ocr-android`, rồi chạy `gradle --no-daemon assembleDebug`. APK nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Giới hạn bản này
- Chỉ nhận dạng chữ Latin (phù hợp tiếng Việt/Anh), có thể sai với ảnh mờ, công thức hoặc bố cục phức tạp. Cần đọc lại OCR trước khi gửi giải.
- Nút nổi là launcher mở app chính, chưa phải một cửa sổ OCR mini đầy đủ.
- Cần thử build/chạy trên thiết bị thật sau khi tạo APK; chưa thể khẳng định app hoạt động hoàn hảo trên mọi điện thoại.
