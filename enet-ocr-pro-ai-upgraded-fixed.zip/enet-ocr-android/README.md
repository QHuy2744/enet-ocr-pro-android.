# eNet OCR Pro — bản nâng cấp AI trong ứng dụng

## Chức năng
- Giao diện tối xanh neon, có logo ứng dụng.
- Chọn nhiều ảnh từ thư viện và nhận diện văn bản ngay trên thiết bị bằng Google ML Kit.
- Chỉnh sửa nội dung OCR trước khi giải.
- Gọi OpenAI API và hiển thị lời giải ngay trong app (không chuyển sang ứng dụng ChatGPT).
- Chọn môn học và dạng hỗ trợ: giải chi tiết, giải thích kiểu THCS, đáp án ngắn, tóm tắt, tạo câu hỏi ôn tập.
- Sao chép, chia sẻ, lưu OCR/lời giải thành TXT, đọc lời giải bằng TTS, tìm và mở lịch sử, nút nổi OCR.

## Cần biết trước khi dùng tính năng AI
- Cần API key riêng lấy từ OpenAI Platform và internet. API tính phí riêng theo mức sử dụng, không đi kèm gói ChatGPT.
- Nhập key bên trong app tại **Cài API key**. Key được lưu trong SharedPreferences riêng của app trên thiết bị; không đưa key vào GitHub hay chia sẻ APK có kèm key. Đây là bản thử nghiệm cá nhân, chưa phải kho lưu trữ key được mã hóa cấp production.
- Mô hình đang đặt là `gpt-4o-mini`; có thể đổi trong `MainActivity.kt` nếu tài khoản/API của bn dùng model khác.
- OCR và TTS chạy cục bộ; riêng lời giải AI được gửi tới dịch vụ OpenAI để xử lý. Không nhập dữ liệu nhạy cảm.

## Build từ GitHub Actions
File ZIP chứa thư mục `enet-ocr-android/` và không có Gradle Wrapper. Hãy dùng workflow cài Gradle trực tiếp, đặt `working-directory: enet-ocr-android`, rồi chạy `gradle --no-daemon assembleDebug`. APK nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Giới hạn bản này
- Chỉ nhận dạng chữ Latin (phù hợp tiếng Việt/Anh), có thể sai với ảnh mờ, công thức hoặc bố cục phức tạp. Cần đọc lại OCR trước khi gửi giải.
- Nút nổi là launcher mở app chính, chưa phải một cửa sổ OCR mini đầy đủ.
- Cần thử build/chạy trên thiết bị thật sau khi tạo APK; chưa thể khẳng định app hoạt động hoàn hảo trên mọi điện thoại.
